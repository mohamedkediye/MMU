//
//  ViewController.swift
//  Portfolio2_Mohamed_Kediye_16038109
//
//  Created by Mohamed kediye on 20/03/2019.
//  Copyright © 2019 Mohamed kediye. All rights reserved.
//

import UIKit
import CoreML
import Vision
import AVKit
import MessageUI
import SafariServices

//view controllers
class ViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate, MFMailComposeViewControllerDelegate, SFSafariViewControllerDelegate, AVCaptureVideoDataOutputSampleBufferDelegate {
    
    
    
    @IBOutlet weak var viewImage: UIImageView! // image view
    @IBOutlet weak var descriptionLabel: UILabel! // label description for identifier
    @IBOutlet weak var faceDetectionLabel: UILabel! // face detection label. this checks for facial recognition
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        let imagePath = Bundle.main.path (forResource: "Kediye" , ofType: "jpg") // image name
        let imageURL = NSURL.fileURL(withPath: imagePath!)
        //let imageURL = NSURL.fileURL (imagePath!)
        
        let modelFile = MobileNet()
        let model =  try! VNCoreMLModel (for: modelFile.model)
        
        let handler = VNImageRequestHandler (url: imageURL)
        let request = VNCoreMLRequest(model: model, completionHandler: findResults)
        
        try! handler.perform([request])
    }


    
    @IBAction func photoLibrary(_ sender: UIBarButtonItem) { getPhoto()
    }
    
    func getPhoto(){
        let imagePicker = UIImagePickerController()
        imagePicker.delegate = self
        imagePicker.sourceType = .photoLibrary
        present(imagePicker, animated: true, completion: nil)
    }
    
    
    
    // this is the function of picking an image that is within the cameraroll
    func imagePickerController(_ picker: UIImagePickerController,didFinishPickingMediaWithInfo info:
        [UIImagePickerController.InfoKey : Any]) {
        // URL information for the chosen image
        if let imgUrl = info[UIImagePickerController.InfoKey.imageURL] as? URL{
            guard let selectedImage =
                info[.originalImage] as? UIImage
                else { return }
            viewImage.image = selectedImage // select image from the camera roll
            identifyFacesWithLandmarks(image: selectedImage)
            
            dismiss(animated: true, completion: nil)
            
            let modelFile = MobileNet()
            let model =  try! VNCoreMLModel (for: modelFile.model)
            let handler = VNImageRequestHandler (url: imgUrl as URL)
            let request = VNCoreMLRequest(model: model, completionHandler: findResults)
            
            try! handler.perform([request])
        }
    }
    
    func findResults(request: VNRequest, error: Error?) {
        guard let results = request.results as?
            [VNClassificationObservation] else{
                fatalError("Unable to get results") // if recognition fails it will show this message
                
                
                // find method for handleFaceLandmarksRecognition
        }
        
        var bestGuess = ""
        var bestConfidence: VNConfidence = 100
        
        for classification in results {
            if (classification.confidence > bestConfidence) {
                bestConfidence = classification.confidence
                bestGuess = classification.identifier
            }
        }
        // the description label states what the image is.
        descriptionLabel.text = "image is: \(bestGuess) with confidence \(bestConfidence) out of 1"
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    
    
    
    func identifyFacesWithLandmarks(image: UIImage) {
        let handler = VNImageRequestHandler(cgImage:
            image.cgImage!, options: [ : ])
        
        faceDetectionLabel.text = "Analyzing picture..."
        
        let request =
            VNDetectFaceLandmarksRequest( completionHandler:
                handleFaceLandmarksRecognition)
        
        try! handler.perform([request])
        
    }
    
    
    func handleFaceLandmarksRecognition(request: VNRequest, error: Error?) {
        guard let foundFaces = request.results as? [VNFaceObservation] else {
            fatalError ("Problem loading picture to examine faces")
        }
        faceDetectionLabel.text = "Found \(foundFaces.count) faces in the picture"
        
        for faceRectangle in foundFaces {
            
            guard let landmarks = faceRectangle.landmarks else {
                continue
            }
            
            var landmarkRegions: [VNFaceLandmarkRegion2D] = []
            
            if let faceContour = landmarks.faceContour {
                landmarkRegions.append(faceContour) //
            }
            if let leftEye = landmarks.leftEye {
                landmarkRegions.append(leftEye)//calculates where the lefy eye is on the face for recognision.
            }
            if let rightEye = landmarks.rightEye {
                landmarkRegions.append(rightEye)//calculates where the right eye is on the face for recognision.
            }
            if let nose = landmarks.nose {
                landmarkRegions.append(nose)//calculates where the nose is on the face for recognision.
            }
            
            drawImage(source: viewImage.image!, boundary: faceRectangle.boundingBox, faceLandmarkRegions: landmarkRegions)
            
        }
        
    }
    
    
    func drawImage(source: UIImage, boundary: CGRect, faceLandmarkRegions: [VNFaceLandmarkRegion2D])  {
        UIGraphicsBeginImageContextWithOptions(source.size, false, 1)
        let context = UIGraphicsGetCurrentContext()!
        context.translateBy(x: 0, y: source.size.height)
        context.scaleBy(x: 1.0, y: -1.0)
        context.setLineJoin(.round)
        context.setLineCap(.round)
        context.setShouldAntialias(true)
        context.setAllowsAntialiasing(true)
        
        // rectangle is created for facial recognision.
        let rect = CGRect(x: 0, y:0, width: source.size.width, height: source.size.height)
        context.draw(source.cgImage!, in: rect)
        
        //this will draw rectangles around faces that it detects facial features and it will draw a rectangle around the face.
        var fillColor = UIColor.green
        fillColor.setStroke()
        
        //the rectangle width will change in width within proportion with the face
        let rectangleWidth = source.size.width * boundary.size.width
        //the rectangle width will change in height within proportion with the face
        let rectangleHeight = source.size.height * boundary.size.height
        
        context.addRect(CGRect(x: boundary.origin.x * source.size.width, y:boundary.origin.y * source.size.height, width: rectangleWidth, height: rectangleHeight))
        context.drawPath(using: CGPathDrawingMode.stroke)
        
        //this draws the facial features such as nose and eyes with a red colour
        fillColor = UIColor.red
        fillColor.setStroke()// this Sets the color of subsequent stroke operations to the color that the receiver represents.
        context.setLineWidth(2.0) //Sets the current line width to 2.0.
        for faceLandmarkRegion in faceLandmarkRegions {
            var points: [CGPoint] = []
            for i in 0..<faceLandmarkRegion.pointCount {
                let point = faceLandmarkRegion.normalizedPoints[i]
                let p = CGPoint(x: CGFloat(point.x), y: CGFloat(point.y))
                points.append(p)
            }
            let facialPoints = points.map { CGPoint(x: boundary.origin.x * source.size.width + $0.x * rectangleWidth, y: boundary.origin.y * source.size.height + $0.y * rectangleHeight) }
            context.addLines(between: facialPoints)
            context.drawPath(using: CGPathDrawingMode.stroke)
        }
        //image modification
        let modifiedImage : UIImage = UIGraphicsGetImageFromCurrentImageContext()!
        UIGraphicsEndImageContext()
        viewImage.image = modifiedImage
    }
    
    


}
